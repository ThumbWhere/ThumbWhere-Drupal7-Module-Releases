# Contributors

## TW SDK for PHP Contributors

Contributions were provided under the Apache 2.0 License, as appropriate.

The following people have provided ideas, support and bug fixes:

* [JamesMcParlane] (http://twitter.com/DrMiaow) (Initial design)


