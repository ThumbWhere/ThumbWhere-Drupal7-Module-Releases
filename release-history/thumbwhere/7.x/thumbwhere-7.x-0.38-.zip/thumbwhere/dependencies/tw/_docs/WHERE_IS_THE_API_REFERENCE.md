You can find the API Reference at:
http://thumbwhere.com/sdk/php/
